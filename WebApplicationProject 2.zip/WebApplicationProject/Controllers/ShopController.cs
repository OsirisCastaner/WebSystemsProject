﻿using Microsoft.AspNetCore.Mvc;
using WebApplicationProject.Models;
using System.Linq;

public class ShopController : Controller
{
    private readonly Database1Context _context;

    public ShopController(Database1Context context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var products = _context.Merchandises.ToList();
        return View(products); 
    }

    public IActionResult SearchProducts(string query)
    {
        var filteredProducts = _context.Merchandises
            .Where(m => m.ItemName.ToLower().Contains(query.ToLower()))
            .ToList();

        return View("Index", filteredProducts); 
    }
}
