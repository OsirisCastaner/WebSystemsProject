﻿using Microsoft.AspNetCore.Mvc;
using WebApplicationProject.Models; 
using Microsoft.AspNetCore.Http;    
using Newtonsoft.Json;
using System.Linq;

public class ShoppingCartController : Controller
{
    private readonly Database1Context _context;

    public ShoppingCartController(Database1Context context)
    {
        _context = context;
    }

    [HttpPost]
    public IActionResult AddTicketToCart(int ticketId)
    {
        var ticket = _context.Tickets.FirstOrDefault(t => t.TicketId == ticketId);
        if (ticket == null)
        {
            return NotFound();
        }

        var cartItem = new ShoppingCartItem
        {
            TicketId = ticket.TicketId,
            MatchDate = ticket.MatchDate?.ToString("yyyy-MM-dd"),
            MatchTime = ticket.MatchTime,
            Fixture = ticket.Fixture,
            LocationName = ticket.LocationName,
            Price = ticket.Price
        };

        var cart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("Cart") ?? new ShoppingCart();
        cart.AddItem(cartItem);
        HttpContext.Session.SetObjectAsJson("Cart", cart);

        TempData["SuccessMessage"] = "Ticket added to cart!";
        return RedirectToAction("Index", "Tickets"); // Redirect back to the Tickets page
    }

    [HttpPost]
    public IActionResult AddItemToCart(int merchId)
    {
        var merchandise = _context.Merchandises.FirstOrDefault(m => m.MerchId == merchId);
        if (merchandise == null)
        {
            return NotFound();
        }

        var cartItem = new ShoppingCartItem
        {
            ProductId = merchandise.MerchId,
            Price = merchandise.Price.ToString(),
            Quantity = merchandise.Quantity,
            ItemName = merchandise.ItemName,
            
        };

        var cart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("Cart") ?? new ShoppingCart();
        cart.AddItem(cartItem);
        HttpContext.Session.SetObjectAsJson("Cart", cart);

        TempData["SuccessMessage"] = $"{merchandise.ItemName} added to cart!";
        return RedirectToAction("Index", "Shop"); // Redirect back to the Shop page
    }


    public IActionResult Index()
    {
        var cart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("Cart");
        return View(cart);
    }

    [HttpPost]
    public IActionResult Checkout(string name, string creditCard)
    {
        var cart = HttpContext.Session.GetObjectFromJson<ShoppingCart>("Cart");

        

        var ticketIds = cart?.Items
            .Where(i => i.TicketId.HasValue)
            .Select(i => i.TicketId.Value)
            .ToList() ?? new List<int>();

        var productIds = cart?.Items
            .Where(i => i.ProductId.HasValue)
            .Select(i => i.ProductId.Value)
            .ToList() ?? new List<int>();

        var confirmationInfo = new OrderConfirmationViewModel
        {
            CustomerName = name,
            CreditCardNumber = creditCard,
            TicketIds = ticketIds,
            ProductIds = productIds 
        };

        // Clear the cart after checkout
        HttpContext.Session.Remove("Cart");

        return View("~/Views/OrderConfirmation/OrderConfirmation.cshtml", confirmationInfo);
    }



}


