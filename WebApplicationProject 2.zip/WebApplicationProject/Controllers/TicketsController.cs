﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using WebApplicationProject.Models;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplicationProject.Controllers
{
    public class TicketsController : Controller
    {
        private readonly Database1Context _context;

        public TicketsController(Database1Context context)
        {
            _context = context;
        }

        public async Task<IActionResult> LocationDetails(int locationId)
        {
            var location = await _context.Locations
                                 .FirstOrDefaultAsync(l => l.LocationId == locationId);

            if (location == null)
            {
                return NotFound();
            }

            return View(location); 
        }

        public async Task<IActionResult> Index()
        {
            var tickets = await _context.Tickets
                             .Include(t => t.Location) 
                             .Select(t => new Ticket
                             {
                                 TicketId = t.TicketId, 
                                 MatchDate = t.MatchDate,
                                 MatchTime = t.MatchTime,
                                 Fixture = t.Fixture,
                                 Price = t.Price,
                                 LocationName = t.LocationName,
                             })
                             .ToListAsync();

            return View(tickets);
        }


    }
}


