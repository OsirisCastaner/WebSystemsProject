﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplicationProject.Models;

public partial class Database1Context : DbContext
{
    public Database1Context()
    {
    }

    public Database1Context(DbContextOptions<Database1Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Atable> Atables { get; set; }

    public virtual DbSet<Location> Locations { get; set; }

    public virtual DbSet<Merchandise> Merchandises { get; set; }

    public virtual DbSet<Ticket> Tickets { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;database=database1;user=root;password=Hellobrogrow02@$", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.35-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Atable>(entity =>
        {
            entity.HasKey(e => e.Name).HasName("PRIMARY");

            entity.ToTable("atable");

            entity.Property(e => e.Name)
                .HasMaxLength(20)
                .HasColumnName("name");
            entity.Property(e => e.Id).HasColumnName("id");
        });

        modelBuilder.Entity<Location>(entity =>
        {
            entity.HasKey(e => e.LocationId).HasName("PRIMARY");

            entity.ToTable("location");

            entity.HasIndex(e => e.LocationId, "location_id").IsUnique();

            entity.Property(e => e.LocationId).HasColumnName("location_id");
            entity.Property(e => e.Row)
                .HasMaxLength(2)
                .HasColumnName("row");
            entity.Property(e => e.Seat).HasColumnName("seat");
            entity.Property(e => e.Section).HasColumnName("section");
        });

        modelBuilder.Entity<Merchandise>(entity =>
        {
            entity.HasKey(e => e.MerchId).HasName("PRIMARY");

            entity.ToTable("merchandise");

            entity.HasIndex(e => e.MerchId, "merch_id").IsUnique();

            entity.Property(e => e.MerchId).HasColumnName("merch_id");
            entity.Property(e => e.ItemName)
                .HasMaxLength(255)
                .HasColumnName("itemName");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.Size)
                .HasMaxLength(255)
                .HasColumnName("size");
        });

        modelBuilder.Entity<Ticket>(entity =>
        {
            entity.HasKey(e => e.TicketId).HasName("PRIMARY");

            entity.ToTable("ticket");

            entity.HasIndex(e => e.LocationId, "location_id");

            entity.HasIndex(e => e.TicketId, "ticket_id").IsUnique();

            entity.Property(e => e.TicketId).HasColumnName("ticket_id");
            entity.Property(e => e.LocationId).HasColumnName("location_id");
            entity.Property(e => e.MatchDate).HasColumnName("match_date");
            entity.Property(e => e.Price)
                .HasMaxLength(5)
                .HasColumnName("price");

            
            entity.Property(e => e.MatchTime)
                .HasColumnName("match_time")
                .HasMaxLength(255);     

            entity.Property(e => e.Fixture)
                .HasColumnName("fixture")
                .HasMaxLength(255);     

            entity.Property(e => e.LocationName) 
                .HasColumnName("location_name")
                .HasMaxLength(255);     

            entity.HasOne(d => d.Location).WithMany(p => p.Tickets)
                .HasForeignKey(d => d.LocationId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("ticket_ibfk_1");
        });


        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
