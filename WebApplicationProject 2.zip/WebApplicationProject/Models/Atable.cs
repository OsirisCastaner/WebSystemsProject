﻿using System;
using System.Collections.Generic;

namespace WebApplicationProject.Models;

public partial class Atable
{
    public string Name { get; set; } = null!;

    public int? Id { get; set; }
}
