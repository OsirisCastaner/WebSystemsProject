﻿using System;
using System.Collections.Generic;

namespace WebApplicationProject.Models;

public partial class Location
{
    public int LocationId { get; set; }

    public int Section { get; set; }

    public string? Row { get; set; }

    public int? Seat { get; set; }

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}
