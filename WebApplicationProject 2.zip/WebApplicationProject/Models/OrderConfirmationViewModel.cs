﻿public class OrderConfirmationViewModel
{
    public string CustomerName { get; set; }
    public string CreditCardNumber { get; set; }
    public List<int> TicketIds { get; set; }
    public List<int> ProductIds { get; set; } 
}
