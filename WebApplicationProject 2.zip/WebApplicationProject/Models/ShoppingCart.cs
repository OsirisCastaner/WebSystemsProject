﻿public class ShoppingCartItem
{
    // For tickets
    public int? TicketId { get; set; }
    public string MatchDate { get; set; }
    public string MatchTime { get; set; }
    public string Fixture { get; set; }
    public string LocationName { get; set; }

    // For merchandise
    public int? ProductId { get; set; }
    public string ItemName { get; set; }
    public int Quantity { get; set; }

    // Common properties
    public string Price { get; set; }


    
    public decimal PriceAsDecimal
    {
        get
        {
            
            if (decimal.TryParse(Price, out decimal parsedPrice))
            {
                return parsedPrice;
            }
            return 0;
        }
    }
}

public class ShoppingCart
{
    public List<ShoppingCartItem> Items { get; set; } = new List<ShoppingCartItem>();

    public void AddItem(ShoppingCartItem item)
    {
        Items.Add(item);
    }

    public decimal Subtotal()
    {
        return Items.Sum(item => item.PriceAsDecimal); 
    }

    public decimal CalculateTax(decimal taxRate)
    {
        return Subtotal() * taxRate; 
    }

    public decimal ShippingCost()
    {
        return 10;
    }

    public decimal TotalPrice(decimal taxRate)
    {
        return Subtotal() + CalculateTax(taxRate) + ShippingCost();
    }
}



