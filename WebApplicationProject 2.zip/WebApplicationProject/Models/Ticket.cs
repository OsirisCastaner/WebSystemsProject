﻿using System;
using System.Collections.Generic;

namespace WebApplicationProject.Models;

public partial class Ticket
{
    public int TicketId { get; set; }

    public int LocationId { get; set; }

    public string? Price { get; set; }

    public DateOnly? MatchDate { get; set; }

    public string? MatchTime { get; set; }
    public string? Fixture { get; set; }
    public string? LocationName { get; set; }

    public virtual Location Location { get; set; } = null!;
}



