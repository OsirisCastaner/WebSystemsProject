﻿using Microsoft.EntityFrameworkCore;
using WebApplicationProject.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add session services
builder.Services.AddSession();

// Register your DbContext
builder.Services.AddDbContext<Database1Context>(options =>
    options.UseMySql("server=localhost;database=database1;user=root;password=Hellobrogrow02@$;\r\n", ServerVersion.AutoDetect("server=localhost;database=database1;user=root;password=Hellobrogrow02@$;\r\n")));


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession(); 

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
