﻿namespace WebApplicationProject.Models;

public class Class1
{

}
