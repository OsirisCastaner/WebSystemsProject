﻿using Microsoft.AspNetCore.Mvc;

public class StreamingController : Controller
{
    public IActionResult Index()
    {
        // Your default action logic
        return View();
    }

    public IActionResult Streaming()
    {
        // Logic for the streaming page
        return View();
    }
}
